var resp = JSON.parse(response.content), // eslint-disable-line
    propertiesToRemove = ['status', 'refresh_token_status', 'api_product_list', 'api_product_list_json',
                          'token_type', 'organization_name', 'developer.email', 'refresh_token_expires_in',
                          'scope', 'refresh_count', 'client_id',
                          'application_name']; 

if (resp.access_token) {
  propertiesToRemove.forEach(function(item){
    delete resp[item];
  });

  // pretty-print JSON
  context.setVariable('response.content', JSON.stringify(resp, null, 2) + '\n');
}